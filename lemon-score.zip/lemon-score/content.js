// Lemon Score — content script для страниц Amazon.
// Что делает: находит ASIN книги, запрашивает сводку у background.js и показывает блок
// с лимонами (на странице книги — с формой оценки, в поиске — компактный значок).
(() => {
  'use strict';
  if (window.__lemonScoreLoaded) return;
  window.__lemonScoreLoaded = true;

  const MIN_RATINGS = 1; // ТЕСТ: перед запуском вернуть 3. Держать в синхроне с c_min_ratings в supabase/schema.sql
  const CONFIDENT_RATINGS = 3; // меньше этого числа оценок вердикт идёт по обычному среднему и с пометкой «мало оценок»
  const ASIN_RE = /^[A-Z0-9]{10}$/;
  const FLAG_KEYS = ['bad_anatomy', 'gibberish_text', 'repetitive', 'messy_lines', 'inconsistent', 'cover_mismatch'];

  // ---------------------------------------------------------------- i18n
  const LANG = (navigator.language || 'en').toLowerCase().startsWith('ru') ? 'ru' : 'en';
  const I18N = {
    en: {
      title: 'Lemon Score',
      loading: 'Loading ratings…',
      retry: 'Retry',
      err_network: 'Could not reach the Lemon Score server.',
      err_not_configured: 'Lemon Score is not configured yet (see config.js).',
      err_generic: 'Something went wrong. Please try again.',
      aiLabel: 'AI suspicion',
      qualityLabel: 'Image quality',
      noQuality: 'no ratings yet',
      verdict_unknown: 'Not enough ratings yet',
      verdict_likely_human: 'Users opinion: likely human-made',
      verdict_mixed: 'Ratings are mixed',
      verdict_suspicious: 'Users suspect AI',
      short_likely_human: 'likely not AI',
      short_mixed: 'mixed',
      short_suspicious: 'suspected AI',
      ratings: { one: '{n} rating', other: '{n} ratings' },
      rate: 'Rate this book',
      yourRating: 'Your rating',
      formAiQ: 'How likely is it that the illustrations are AI-generated?',
      formQualityQ: 'How good are the illustrations? (optional)',
      formFlagsQ: 'What looks off? (optional)',
      ai0: 'No signs of AI',
      ai1: 'Hardly any signs',
      ai2: 'A few doubts',
      ai3: 'Suspicious',
      ai4: 'Very likely AI',
      ai5: 'Definitely AI',
      q1: 'Poor',
      q2: 'Weak',
      q3: 'Okay',
      q4: 'Good',
      q5: 'Excellent',
      flag_bad_anatomy: 'Odd hands / anatomy',
      flag_gibberish_text: 'Gibberish text',
      flag_repetitive: 'Repetitive elements',
      flag_messy_lines: 'Messy or blurry lines',
      flag_inconsistent: 'Illogical details',
      flag_cover_mismatch: 'Cover ≠ inside',
      submit: 'Submit rating',
      sending: 'Sending…',
      cancel: 'Cancel',
      pickAi: 'Please choose how AI-like the book looks.',
      thanks: 'Thank you! Your rating has been saved.',
      alreadyRated: 'You have already rated this book from this device.',
      rateLimited: 'Too many ratings in a short time. Please try again later.',
      noRatingsShort: 'Not rated yet',
      notAi: 'Not AI',
      fewRatings: 'few ratings, may change',
      fewShort: 'few ratings',
      change: 'Change rating',
      update: 'Update rating',
      updated: 'Your rating has been updated.',
      todoTag: 'Not rated by you',
      aiScaleHint: 'The more you suspect AI, the more lemons to give. If you think a human drew it, choose 0.',
      doneTag: 'You rated',
    },
    ru: {
      title: 'Lemon Score',
      loading: 'Загружаю оценки…',
      retry: 'Повторить',
      err_network: 'Не удалось связаться с сервером Lemon Score.',
      err_not_configured: 'Lemon Score ещё не настроен (см. config.js).',
      err_generic: 'Что-то пошло не так. Попробуйте ещё раз.',
      aiLabel: 'Подозрение на ИИ',
      qualityLabel: 'Качество картинок',
      noQuality: 'пока нет оценок',
      verdict_unknown: 'Пока мало оценок',
      verdict_likely_human: 'Читатели: скорее всего рисовал человек',
      verdict_mixed: 'Мнения расходятся',
      verdict_suspicious: 'Читатели подозревают ИИ',
      short_likely_human: 'скорее не ИИ',
      short_mixed: 'спорно',
      short_suspicious: 'подозрение на ИИ',
      ratings: { one: '{n} оценка', few: '{n} оценки', many: '{n} оценок', other: '{n} оценки' },
      rate: 'Оценить книгу',
      yourRating: 'Ваша оценка',
      formAiQ: 'Насколько вероятно, что иллюстрации сделаны ИИ?',
      formQualityQ: 'Насколько хороши иллюстрации? (необязательно)',
      formFlagsQ: 'Что вызвало подозрения? (необязательно)',
      ai0: 'Признаков ИИ нет',
      ai1: 'Почти нет признаков',
      ai2: 'Есть сомнения',
      ai3: 'Подозрительно',
      ai4: 'Очень похоже на ИИ',
      ai5: 'Точно ИИ',
      q1: 'Плохое',
      q2: 'Слабое',
      q3: 'Нормальное',
      q4: 'Хорошее',
      q5: 'Отличное',
      flag_bad_anatomy: 'Странные руки / анатомия',
      flag_gibberish_text: 'Бессмысленный текст',
      flag_repetitive: 'Повторяющиеся элементы',
      flag_messy_lines: 'Мутные или рваные линии',
      flag_inconsistent: 'Нелогичные детали',
      flag_cover_mismatch: 'Обложка ≠ содержимое',
      submit: 'Отправить оценку',
      sending: 'Отправляю…',
      cancel: 'Отмена',
      pickAi: 'Сначала выберите, насколько книга похожа на ИИ.',
      thanks: 'Спасибо! Ваша оценка сохранена.',
      alreadyRated: 'Вы уже оценили эту книгу с этого устройства.',
      rateLimited: 'Слишком много оценок за короткое время. Попробуйте позже.',
      noRatingsShort: 'Пока без оценок',
      notAi: 'Не ИИ',
      fewRatings: 'мало оценок, может измениться',
      fewShort: 'мало оценок',
      change: 'Изменить оценку',
      update: 'Обновить оценку',
      updated: 'Ваша оценка обновлена.',
      todoTag: 'Не оценено вами',
      aiScaleHint: 'Чем сильнее подозрение на ИИ, тем больше лимонов. Если считаете, что нарисовал человек, поставьте 0.',
      doneTag: 'Вы оценили',
    },
  };
  const t = (key) => I18N[LANG][key] ?? I18N.en[key] ?? key;
  const plural = (key, n) => {
    const forms = I18N[LANG][key];
    const form = forms[new Intl.PluralRules(LANG).select(n)] || forms.other;
    return form.replace('{n}', String(n));
  };

  // ------------------------------------------------------------- helpers
  const h = (tag, props, ...children) => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  };

  const alive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };

  const send = async (msg) => {
    try {
      if (!alive()) return { ok: false, error: 'context' };
      return (await chrome.runtime.sendMessage(msg)) || { ok: false, error: 'network' };
    } catch {
      return { ok: false, error: 'network' };
    }
  };

  const errText = (code) =>
    code === 'not_configured'
      ? t('err_not_configured')
      : code === 'network'
        ? t('err_network')
        : `${t('err_generic')} (${String(code || 'unknown')})`;

  // ---------------------------------------------------------- page info
  const marketplace = (() => {
    const m = location.hostname.toLowerCase().match(/(?:^|\.)amazon\.([a-z]{2,3}(?:\.[a-z]{2,3})?)$/);
    return m ? m[1] : null;
  })();
  if (!marketplace) return;

  const productAsin = () => {
    const m = location.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d|product)\/([A-Za-z0-9]{10})(?=\/|$)/);
    return m ? m[1].toUpperCase() : null;
  };
  const pageKind = () => {
    if (productAsin()) return 'product';
    if (location.pathname === '/s' || location.pathname.startsWith('/s/')) return 'search';
    // страница автора: /stores/<Имя>/author/<ID>, /stores/author/<ID>/allbooks (вкладки Home и All Books), /e/<ID>
    if (/(?:^|\/)(?:stores|e)\/|\/author\//.test(location.pathname)) return 'author';
    return null;
  };

  // Не показываем блок на не-книгах (карандаши, наушники...). Эвристика по нескольким признакам.
  const isBookProduct = () => {
    if (
      document.querySelector(
        '#nav-subnav[data-category="stripbooks"], #bookDescription_feature_div, [id^="rpi-attribute-book_details"]'
      )
    )
      return true;
    if (document.querySelector('#bylineInfo .author, #bylineInfo_feature_div .author')) return true;
    const details = document.querySelector('#detailBullets_feature_div, #productDetails_detailBullets_sections1, #prodDetails');
    return !!(details && /ISBN/i.test(details.textContent || ''));
  };

  // ---------------------------------------- данные книги для сайта Lemon Score
  // Название, автор и обложка уходят на сервер вместе с оценкой: сайт не может сам читать страницы Amazon.
  const cleanText = (s, max) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, max);
  const COVER_RE = /^https:\/\/(m\.media-amazon\.com|images-na\.ssl-images-amazon\.com|images-eu\.ssl-images-amazon\.com|images-fe\.ssl-images-amazon\.com)\/images\/[IP]\/[A-Za-z0-9._%+,-]+$/;
  const coverUrl = () => {
    const img = document.querySelector('#landingImage, #imgBlkFront, #ebooksImgBlkFront, #main-image, #imgTagWrapperId img');
    if (!img) return null;
    const candidates = [img.getAttribute('data-old-hires'), img.currentSrc, img.getAttribute('src')];
    // data-a-dynamic-image: {"url": [w, h], ...} — берём самую большую картинку
    try {
      const dyn = JSON.parse(img.getAttribute('data-a-dynamic-image') || '{}');
      const best = Object.entries(dyn).sort((a, b) => (b[1]?.[0] || 0) - (a[1]?.[0] || 0))[0];
      if (best) candidates.unshift(best[0]);
    } catch {
      /* нет данных — не страшно */
    }
    for (const c of candidates) {
      const url = String(c || '').split('?')[0];
      if (COVER_RE.test(url)) return url;
    }
    return null;
  };
  const authorName = () => {
    const authors = [...document.querySelectorAll('#bylineInfo .author, #bylineInfo_feature_div .author')];
    // Сначала тот, кто подписан как Author (а не Illustrator / Editor), иначе первый в списке
    const main =
      authors.find((a) => /author|autor|auteur|autore|författare|著/i.test(a.querySelector('.contribution')?.textContent || '')) ||
      authors[0];
    const name = main?.querySelector('a.a-link-normal, .contributorNameID, a')?.textContent || '';
    return cleanText(name, 120) || null;
  };
  const bookMeta = () => ({
    title: cleanText(document.querySelector('#productTitle, #ebooksProductTitle')?.textContent, 300) || null,
    author: authorName(),
    coverUrl: coverUrl(),
  });

  // ---------------------------------------- форматы одной книги (Paperback / Spiral-bound / Kindle ...)
  // На странице книги Amazon показывает переключатель форматов со ссылками на ASIN каждого формата.
  // Читаем эти ASIN и сообщаем серверу, что это одна книга: оценки у форматов общие.
  const FORMAT_BLOCKS = '#tmmSwatches, #twister_feature_div, #twister-plus-inline-twister, #formats, #mediaTabs_tabSet';
  const ASIN_IN_URL = /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Za-z0-9]{10})(?=[/?#]|$)/;
  const MAX_FORMATS = 8; // держать в синхроне с c_max_group в schema.sql
  const formatAsins = (currentAsin) => {
    const found = new Set([currentAsin]);
    for (const block of document.querySelectorAll(FORMAT_BLOCKS)) {
      for (const a of block.querySelectorAll('a[href]')) {
        const m = (a.getAttribute('href') || '').match(ASIN_IN_URL);
        if (m) found.add(m[1].toUpperCase());
      }
      for (const el of block.querySelectorAll('[data-asin]')) {
        const v = (el.getAttribute('data-asin') || '').toUpperCase();
        if (ASIN_RE.test(v)) found.add(v);
      }
    }
    // запасной путь: карта «вариант -> ASIN» в служебных данных страницы
    if (found.size < 2) {
      for (const s of document.querySelectorAll('script:not([src])')) {
        const text = s.textContent || '';
        if (!text.includes('dimensionToAsinMap')) continue;
        const m = text.match(/"dimensionToAsinMap"\s*:\s*\{([^}]*)\}/);
        if (!m) continue;
        for (const v of m[1].matchAll(/"([A-Z0-9]{10})"/g)) found.add(v[1]);
        break;
      }
    }
    // больше MAX_FORMATS — скорее всего, захватили лишнее, такой набор не отправляем
    return found.size >= 2 && found.size <= MAX_FORMATS ? [...found] : [];
  };

  // ------------------------------------------------ фильтр: только раскраски из раздела Books
  // Текст приводим к виду без акцентов и регистра (målarbok -> malarbok), поэтому слова ниже без диакритики.
  const fold = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  // Слова «раскраска» для маркетплейсов из manifest.json (en, de, fr, it, es, pt, nl, sv, pl, ja) + ru.
  // Новый язык добавляется в этот список одной строкой.
  const COLORING_WORDS = [
    'colou?ring', // coloring / colouring (en)
    'colou?r(?:ing)? by number',
    'coloriage', 'colorier', // fr
    'malbuch', 'ausmal', // de: Malbuch, Ausmalbuch, Ausmalbilder
    'colorare', // it: libro da colorare
    'colorear', 'libro para pintar', // es
    'colorir', 'livro de pintar', // pt-BR
    'kleurboek', 'kleurplaat', 'kleurplaten', // nl
    'malarbok', 'farglagg', // sv
    'kolorowank', // pl
    '塗り絵', 'ぬりえ', 'ヌリエ', // ja
    'раскраск', // ru
  ];
  const COLORING_RE = new RegExp(COLORING_WORDS.join('|'), 'i');
  const isColoringText = (s) => COLORING_RE.test(fold(s));

  // На странице книги ищем «раскраску» в названии, подзаголовке, категориях (хлебные крошки)
  // и в рейтинге продаж («#12 in Coloring Books for Grown-Ups»). Отзывы и «похожие товары» не смотрим.
  const COLORING_SIGNAL_SELECTORS = [
    '#productTitle',
    '#title',
    '#productSubtitle',
    '#wayfinding-breadcrumbs_feature_div',
    '#detailBulletsWrapper_feature_div',
    '#detailBullets_feature_div',
    '#productDetails_detailBullets_sections1',
    '#prodDetails',
  ];
  const isColoringProduct = () => {
    const text = COLORING_SIGNAL_SELECTORS.map((sel) => document.querySelector(sel)?.textContent || '').join(' ');
    return isColoringText(text) || isColoringText(document.title);
  };

  // На странице поиска: показываем значок только у раскрасок из раздела Books.
  const FORMAT_RE =
    /paperback|hardcover|kindle|board book|spiral[- ]bound|taschenbuch|gebundene ausgabe|broschiert|broché|relié|copertina|tapa blanda|tapa dura|ペーパーバック|単行本|capa comum|capa dura|boek/i;
  const looksLikeColoringBook = (card) => {
    const params = new URLSearchParams(location.search);
    const inBooksDept = /^stripbooks/i.test(params.get('i') || '');
    // слово «coloring» в названии карточки, либо поиск именно раскрасок внутри раздела Books
    const title = card.querySelector('h2')?.textContent || card.querySelector('[data-cy="title-recipe"]')?.textContent || '';
    const coloring = isColoringText(title) || (inBooksDept && isColoringText(params.get('k')));
    if (!coloring) return false;
    // «Coloring markers» и т.п. — не книги: нужен раздел Books либо формат книги в карточке
    return inBooksDept || FORMAT_RE.test(card.textContent || '');
  };

  // -------------------------------------------------------------- styles
  const STYLE = `
    .card, .card * { box-sizing: border-box; }
    .card { all: initial; display: block; box-sizing: border-box; max-width: 540px; padding: 10px 14px;
            border: 1px solid #d5d9d9; border-radius: 10px; background: #fff; color: #0f1111;
            font: 14px/1.4 "Amazon Ember", Arial, sans-serif; }
    .head { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; font-weight: 700; font-size: 15px; }
    .head .logo { font-size: 18px; }
    .row { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin: 4px 0; }
    .lbl { color: #565959; min-width: 110px; }
    .meter { display: inline-flex; }
    .ico { font-size: 18px; line-height: 1; margin-right: 1px; }
    .ico.off { filter: grayscale(1); opacity: .28; }
    .num { font-weight: 700; }
    .muted { color: #565959; font-size: 13px; }
    .err { color: #b12704; }
    .pill, .spill { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 12px; font-weight: 700; }
    .spill { all: initial; display: inline-block; font: 700 12px/1.5 Arial, sans-serif; padding: 1px 9px; border-radius: 12px; }
    .unknown { background: #eef0f1; color: #565959; }
    .likely_human { background: #e3f4e8; color: #0b6b2a; }
    .mixed { background: #fff1cc; color: #7a5200; }
    .suspicious { background: #fde3e0; color: #b12704; }
    .mine { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 8px; padding-top: 8px; border-top: 1px solid #e7e7e7; }
    .notice { width: 100%; font-size: 13px; }
    .notice.ok { color: #067d62; } .notice.err { color: #b12704; } .notice.info { color: #565959; }
    .form { margin-top: 8px; padding-top: 4px; border-top: 1px solid #e7e7e7; }
    .q { font-weight: 700; margin: 10px 0 4px; }
    .scale { margin: 0 0 6px; color: #565959; font-size: 12px; }
    .hint { min-height: 18px; margin-top: 2px; color: #565959; font-size: 12px; }
    .picker { display: flex; align-items: center; gap: 2px; }
    .pk { all: unset; display: inline-block; cursor: pointer; font-size: 26px; line-height: 1; padding: 2px 3px; border-radius: 6px; }
    .pk.off { filter: grayscale(1); opacity: .3; }
    .pk:hover { transform: scale(1.12); }
    /* Предпросмотр при наведении: все лимоны до наведённого слегка окрашиваются, наведённый ещё и крупнее.
       Уже выбранные лимоны правее наведённого на время наведения гаснут. */
    .pk.off:hover, .pk.on:hover { filter: none; opacity: 1; }
    .pk.off:has(~ .pk:hover) { filter: grayscale(.25); opacity: .75; }
    .picker:has(.pk:hover) .pk.on:not(:hover):not(:has(~ .pk:hover)) { filter: grayscale(1); opacity: .3; }
    .zero { all: unset; display: inline-block; cursor: pointer; width: 26px; height: 26px; margin-right: 8px; border: 1.5px solid #c7ccd0;
            border-radius: 50%; text-align: center; line-height: 23px; font-weight: 700; color: #565959; box-sizing: border-box; }
    .zero.on { background: #067d62; border-color: #067d62; color: #fff; }
    .chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 4px 0 8px; }
    .chip { all: unset; display: inline-block; cursor: pointer; padding: 3px 10px; border: 1px solid #d5d9d9; border-radius: 14px;
            font-size: 12px; background: #fff; color: #0f1111; }
    .chip[aria-pressed="true"] { background: #fde3e0; border-color: #e0a0a0; color: #8a1f11; font-weight: 700; }
    .actions { display: flex; align-items: center; margin-top: 10px; }
    .btn { all: unset; display: inline-block; cursor: pointer; padding: 6px 16px; border: 1px solid #fcd200; border-radius: 20px;
           background: #ffd814; color: #0f1111; font-size: 13px; box-sizing: border-box; }
    .btn:hover { background: #f7ca00; }
    .btn[disabled] { opacity: .6; cursor: default; }
    .link { all: unset; cursor: pointer; margin-left: 12px; color: #007185; font-size: 13px; }
    .link:hover { color: #c7511f; text-decoration: underline; }
    .mytag { all: initial; display: inline-block; margin-left: 6px; font: 700 12px/1.5 Arial, sans-serif; padding: 1px 9px; border-radius: 12px; }
    .mytag.todo { background: #ff6a00; color: #111; }
    .mytag.done { background: #e3f4e8; color: #0b6b2a; }
    .pk:focus-visible, .zero:focus-visible, .chip:focus-visible, .btn:focus-visible, .link:focus-visible { outline: 2px solid #007185; outline-offset: 2px; }
  `;

  const meter = (icon, filled, label) => {
    const wrap = h('span', { class: 'meter', role: 'img', 'aria-label': label || '' });
    for (let i = 1; i <= 5; i++) {
      wrap.append(h('span', { class: 'ico ' + (i <= filled ? 'on' : 'off'), 'aria-hidden': 'true' }, icon));
    }
    return wrap;
  };

  // Что показывать для книги: вердикт, обычное среднее и признак «оценок мало».
  // При малом числе оценок вердикт считаем по обычному среднему, чтобы слова не спорили с числом.
  const bandOf = (avg) => (avg <= 1.5 ? 'likely_human' : avg >= 3.5 ? 'suspicious' : 'mixed');
  const viewOf = (row) => {
    const n = row?.ratings_count || 0;
    if (!row || n < MIN_RATINGS) return { n, verdict: 'unknown', avg: 0, few: false };
    const avg = Number(row.avg_ai);
    const few = n < CONFIDENT_RATINGS;
    const verdict = few || row.verdict === 'unknown' ? bandOf(avg) : row.verdict;
    return { n, verdict, avg, few };
  };

  const verdictText = (verdict, n) =>
    verdict === 'unknown' && n > 0
      ? `${t('verdict_unknown')} (${n}/${MIN_RATINGS})`
      : t('verdict_' + verdict);

  // ------------------------------------------------- подсветка неоценённых и «увиденные» книги
  // Неоценённая книга (этим устройством) получает атрибут data-lemon-unrated, оценённая — data-lemon-rated.
  // Подсвечивает неоценённые общий CSS ниже; его можно выключить в окошке расширения (настройка highlightUnrated).
  const SETTINGS_KEY = 'settings';
  const PAGE_STYLE = `
    html[data-lemon-hl] [data-lemon-unrated] {
      outline: 3px solid #ff6a00 !important; outline-offset: -3px;
      box-shadow: 0 0 0 4px rgba(255, 106, 0, .25) !important;
      border-radius: 10px; background-color: #fff1df !important;
    }
    html[data-lemon-hl] [data-lemon-unrated] .puis-card-container,
    html[data-lemon-hl] [data-lemon-unrated] .s-card-container { background-color: #fff1df !important; }
  `;
  const applyHighlight = (on) => document.documentElement.toggleAttribute('data-lemon-hl', !!on);
  const initHighlight = () => {
    const style = document.createElement('style');
    style.id = 'lemon-score-page-style';
    style.textContent = PAGE_STYLE;
    (document.head || document.documentElement).append(style);
    applyHighlight(true); // по умолчанию включено, пока не прочитали настройку
    try {
      chrome.storage.local
        .get(SETTINGS_KEY)
        .then(({ settings }) => applyHighlight(settings?.highlightUnrated !== false))
        .catch(() => {});
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes[SETTINGS_KEY]) applyHighlight(changes[SETTINGS_KEY].newValue?.highlightUnrated !== false);
      });
    } catch {
      /* хранилище недоступно — остаётся включённой */
    }
  };
  initHighlight();

  // el — карточка / плитка / виджет; row — сводка по книге из getStats (null — оценок нет вообще)
  const markCard = (el, row) => {
    if (!el) return;
    if (row && row.my_ai_score != null) {
      el.removeAttribute('data-lemon-unrated');
      el.setAttribute('data-lemon-rated', '1');
    } else {
      el.removeAttribute('data-lemon-rated');
      el.setAttribute('data-lemon-unrated', '1');
    }
  };

  // Обложка из карточки в поиске: убираем размер из имени файла и просим картинку побольше.
  const normCover = (u) => {
    const url = String(u || '').split('?')[0];
    const big = url.replace(/\._[A-Za-z0-9_,%-]+_\.(jpg|jpeg|png|webp)$/i, '._AC_UL400_.$1');
    return COVER_RE.test(big) ? big : null;
  };
  const AUTHOR_LINKS = 'a[href*="/e/"], a[href*="field-author"], a[href*="p_27"]';
  const BY_RE = /^\s*(?:by|von|de|di|door|av|od|著者|от)\s+(.+?)\s*(?:\||$)/i;
  const cardAuthor = (card) => {
    for (const a of card.querySelectorAll(AUTHOR_LINKS)) {
      if (a.closest('h2')) continue;
      const name = cleanText(a.textContent, 120);
      if (name.length >= 2) return name;
    }
    for (const row of card.querySelectorAll('.a-row.a-size-base.a-color-secondary, .a-row.a-color-secondary')) {
      const m = BY_RE.exec(cleanText(row.textContent, 200));
      if (m) return cleanText(m[1], 120) || null;
    }
    return null;
  };
  const cardMeta = (card) => ({
    title:
      cleanText(card.querySelector('h2')?.textContent || card.querySelector('[data-cy="title-recipe"]')?.textContent, 300) || null,
    author: cardAuthor(card),
    coverUrl: normCover((card.querySelector('img.s-image') || card.querySelector('img'))?.getAttribute('src')),
  });

  // Сообщить серверу, какие книги увидел пользователь (в очередь «что ещё оценить»). Ошибки не важны.
  const reportSeen = (items) => {
    const list = items.filter((i) => i && ASIN_RE.test(i.asin));
    if (list.length) send({ type: 'recordSeen', items: list });
  };

  // Применить сводки к бейджам и подсветить карточки. jobs: [{ asin, badge, el }]
  const applyStats = (jobs) => {
    if (!jobs.length) return;
    send({ type: 'getStats', marketplace, asins: [...new Set(jobs.map((j) => j.asin))] }).then((resp) => {
      for (const { asin, badge, el } of jobs) {
        if (resp.ok) {
          const row = resp.stats?.[asin] || null;
          badge.set(row);
          markCard(el, row);
        } else badge.host.remove(); // не засоряем выдачу сообщениями об ошибках
      }
    });
  };

  // ------------------------------------------------- виджет на странице книги
  const createProductWidget = (asin) => {
    const host = h('div', { 'data-lemon-score': asin });
    host.style.cssText = 'display:block;margin:8px 0;';
    const root = host.attachShadow({ mode: 'open' });
    root.append(h('style', {}, STYLE));
    const card = h('div', { class: 'card' });
    root.append(card);

    const st = {
      phase: 'loading', // loading | ready | error
      error: null,
      stats: null,
      open: false,
      editing: false,
      ai: null,
      quality: null,
      flags: new Set(),
      busy: false,
      notice: null,
    };

    const load = async () => {
      st.phase = 'loading';
      render();
      const resp = await send({ type: 'getStats', marketplace, asins: [asin] });
      if (resp.ok) {
        st.phase = 'ready';
        st.stats = resp.stats?.[asin] || null;
        st.error = null;
        send({ type: 'recordSeen', items: [{ asin, ...bookMeta() }] });
        // Книгу уже оценивали, но у сервера нет её названия / автора / обложки (например, оценки
        // ставились старой версией расширения) — досылаем, чтобы книга нормально выглядела на сайте.
        if (st.stats && st.stats.ratings_count > 0 && st.stats.has_meta === false) {
          send({ type: 'upsertMeta', marketplace, asin, ...bookMeta() });
        }
      } else {
        st.phase = 'error';
        st.error = resp.error;
      }
      render();
    };

    // Тихое обновление сводки (без «Loading…»): после того как сервер связал форматы.
    const refresh = async () => {
      const resp = await send({ type: 'getStats', marketplace, asins: [asin] });
      if (resp.ok && st.phase === 'ready') {
        st.stats = resp.stats?.[asin] || null;
        render();
      }
    };

    const submit = async () => {
      if (st.ai == null) {
        st.notice = { kind: 'err', text: t('pickAi') };
        render();
        return;
      }
      st.busy = true;
      st.notice = null;
      render();
      const resp = await send({
        type: 'submitRating',
        marketplace,
        asin,
        aiScore: st.ai,
        qualityScore: null,
        flags: [...st.flags],
        ...bookMeta(),
      });
      st.busy = false;
      const r = resp.ok ? resp.result : null;
      if (r && (r.status === 'ok' || r.status === 'updated' || r.status === 'already_rated')) {
        st.stats = r.stats || st.stats;
        st.open = false;
        st.editing = false;
        st.notice =
          r.status === 'ok'
            ? { kind: 'ok', text: t('thanks') }
            : r.status === 'updated'
              ? { kind: 'ok', text: t('updated') }
              : { kind: 'info', text: t('alreadyRated') };
      } else if (r && r.status === 'rate_limited') {
        st.notice = { kind: 'err', text: t('rateLimited') };
      } else {
        st.notice = { kind: 'err', text: resp.ok ? t('err_generic') : errText(resp.error) };
      }
      render();
    };

    const noticeEl = () => (st.notice ? h('div', { class: 'notice ' + st.notice.kind }, st.notice.text) : null);

    const summary = () => {
      if (st.phase === 'loading') return h('div', { class: 'muted' }, t('loading'));
      if (st.phase === 'error') {
        return h('div', { class: 'err' }, errText(st.error), ' ', h('button', { class: 'link', type: 'button', onclick: load }, t('retry')));
      }
      const s = st.stats;
      const { n, verdict, avg, few } = viewOf(s);
      const aiFilled = verdict === 'unknown' ? 0 : Math.round(avg);
      return h(
        'div',
        { class: 'summary' },
        h(
          'div',
          { class: 'row' },
          h('span', { class: 'lbl' }, t('aiLabel')),
          meter('🍋', aiFilled, t('aiLabel')),
          verdict === 'unknown' ? null : h('span', { class: 'num' }, avg.toFixed(1) + ' / 5')
        ),
        h(
          'div',
          { class: 'row' },
          h('span', { class: 'pill ' + verdict }, verdictText(verdict, n)),
          h('span', { class: 'muted' }, plural('ratings', n) + (few ? ' · ' + t('fewRatings') : ''))
        )
      );
    };

    const picker = (kind, icon, min, max, value, onPick) => {
      const wrap = h('div', { class: 'picker', role: 'radiogroup' });
      // Подпись под лимонами при наведении (и фокусе с клавиатуры) показывает значение лимона под курсором;
      // когда курсор уходит — возвращается подпись выбранной оценки.
      const setHint = (text) => {
        const hint = root.querySelector('.hint');
        if (hint) hint.textContent = text;
      };
      const showPicked = () => setHint(value != null ? t(kind + value) : ' ');
      wrap.addEventListener('mouseleave', showPicked);
      if (min === 0) {
        wrap.append(
          h(
            'button',
            {
              class: 'zero' + (value === 0 ? ' on' : ''),
              type: 'button',
              role: 'radio',
              'aria-checked': String(value === 0),
              'aria-label': t(kind + '0'),
              'data-key': kind + '-0',
              title: t(kind + '0'),
              onmouseenter: () => setHint(t(kind + '0')),
              onfocus: () => setHint(t(kind + '0')),
              onblur: showPicked,
              onclick: () => onPick(0),
            },
            '0'
          )
        );
      }
      for (let v = Math.max(min, 1); v <= max; v++) {
        wrap.append(
          h(
            'button',
            {
              class: 'pk ' + (value != null && v <= value ? 'on' : 'off'),
              type: 'button',
              role: 'radio',
              'aria-checked': String(value === v),
              'aria-label': t(kind + v),
              'data-key': kind + '-' + v,
              title: t(kind + v),
              onmouseenter: () => setHint(t(kind + v)),
              onfocus: () => setHint(t(kind + v)),
              onblur: showPicked,
              onclick: () => onPick(v),
            },
            icon
          )
        );
      }
      return wrap;
    };

    const form = () =>
      h(
        'div',
        { class: 'form' },
        noticeEl(),
        h('div', { class: 'q' }, t('formAiQ')),
        h('div', { class: 'scale' }, t('aiScaleHint')),
        picker('ai', '🍋', 0, 5, st.ai, (v) => {
          st.ai = v;
          st.notice = null;
          render();
        }),
        h('div', { class: 'hint' }, st.ai != null ? t('ai' + st.ai) : ' '),
        h(
          'div',
          { class: 'actions' },
          h('button', { class: 'btn', type: 'button', disabled: st.busy, onclick: submit }, st.busy ? t('sending') : st.editing ? t('update') : t('submit')),
          h(
            'button',
            {
              class: 'link',
              type: 'button',
              disabled: st.busy,
              onclick: () => {
                st.open = false;
                st.editing = false;
                st.notice = null;
                render();
              },
            },
            t('cancel')
          )
        )
      );

    const rateArea = () => {
      if (st.phase !== 'ready') return null;
      const s = st.stats;
      if (st.open) return form();
      if (s && s.my_ai_score != null) {
        // Это устройство уже оценивало книгу (сервер знает по device_id): показываем оценку и даём её изменить.
        return h(
          'div',
          { class: 'mine' },
          noticeEl(),
          h('span', { class: 'lbl' }, t('yourRating') + ':'),
          s.my_ai_score === 0
            ? h('span', { class: 'pill likely_human' }, t('notAi'))
            : [meter('🍋', s.my_ai_score, t('ai' + s.my_ai_score)), h('span', { class: 'muted' }, t('ai' + s.my_ai_score))],
          h(
            'button',
            {
              class: 'link',
              type: 'button',
              'data-key': 'change',
              onclick: () => {
                st.ai = s.my_ai_score;
                st.flags = new Set((s.my_flags || []).filter((f) => FLAG_KEYS.includes(f)));
                st.editing = true;
                st.open = true;
                st.notice = null;
                render();
              },
            },
            t('change')
          )
        );
      }
      return h(
        'div',
        { class: 'mine' },
        noticeEl(),
        h(
          'button',
          {
            class: 'btn',
            type: 'button',
            onclick: () => {
              st.open = true;
              st.notice = null;
              render();
            },
          },
          t('rate')
        )
      );
    };

    const render = () => {
      const focusKey = root.activeElement?.getAttribute?.('data-key');
      const unrated = st.phase === 'ready' && !(st.stats && st.stats.my_ai_score != null);
      const header = h('div', { class: 'head' }, h('span', { class: 'logo' }, '🍋'), h('span', {}, t('title')), unrated ? h('span', { class: 'mytag todo' }, t('todoTag')) : null);
      if (st.phase === 'ready') markCard(host, st.stats);
      card.replaceChildren(...[header, summary(), rateArea()].filter(Boolean));
      if (focusKey) root.querySelector(`[data-key="${focusKey}"]`)?.focus();
    };

    return { host, load, refresh };
  };

  // ------------------------------------------------ значок в результатах поиска
  const createBadge = () => {
    const host = h('div', { 'data-lemon-badge': '1' });
    host.style.cssText = 'display:block;margin:4px 0;';
    const root = host.attachShadow({ mode: 'open' });
    root.append(h('style', {}, STYLE));
    const pill = h('span', { class: 'spill unknown' }, '🍋 ' + t('loading'));
    const tag = h('span', { class: 'mytag', hidden: true });
    root.append(pill, tag);

    const set = (row) => {
      const { n, verdict, avg, few } = viewOf(row);
      pill.className = 'spill ' + verdict;
      const mine = row?.my_ai_score;
      tag.hidden = false;
      tag.className = 'mytag ' + (mine == null ? 'todo' : 'done');
      tag.textContent = mine == null ? t('todoTag') : `✓ ${t('doneTag')}: ${mine}/5`;
      if (!row) {
        pill.textContent = '🍋 ' + t('noRatingsShort');
        pill.title = t('noRatingsShort');
      } else if (verdict === 'unknown') {
        pill.textContent = '🍋 ' + plural('ratings', n);
        pill.title = verdictText(verdict, n);
      } else {
        pill.textContent = `🍋 ${avg.toFixed(1)} · ${t('short_' + verdict)} (${few ? n + ', ' + t('fewShort') : n})`;
        pill.title = `${verdictText(verdict, n)} — ${plural('ratings', n)}${few ? ', ' + t('fewRatings') : ''}`;
      }
    };
    return { host, set };
  };

  const scanSearch = () => {
    const cards = document.querySelectorAll('[data-component-type="s-search-result"][data-asin]:not([data-lemon])');
    const jobs = [];
    for (const card of cards) {
      const asin = (card.getAttribute('data-asin') || '').toUpperCase();
      if (!ASIN_RE.test(asin)) continue;
      card.setAttribute('data-lemon', '1');
      if (!looksLikeColoringBook(card)) continue;
      const anchor = card.querySelector('[data-cy="title-recipe"]') || card.querySelector('h2')?.parentElement;
      if (!anchor) continue;
      const badge = createBadge();
      anchor.insertAdjacentElement('afterend', badge.host);
      jobs.push({ asin, badge, el: card, meta: cardMeta(card) });
    }
    applyStats(jobs);
    reportSeen(jobs.map((j) => ({ asin: j.asin, ...j.meta })));
  };

  // Карусели на странице поиска («Customers frequently viewed», «Sponsored» и т.п.): это не обычные результаты,
  // у карточек другая разметка, ASIN берём из data-asin либо из ссылки (в том числе рекламной, /sspa/click?url=…%2Fdp%2FASIN).
  const DP_IN_HREF = /(?:\/dp\/|%2Fdp%2F|\/gp\/product\/|%2Fgp%2Fproduct%2F)([A-Z0-9]{10})(?![A-Z0-9])/i;
  const carouselAsin = (el) => {
    const own = (el.getAttribute('data-asin') || el.querySelector('[data-asin]')?.getAttribute('data-asin') || '').toUpperCase();
    if (ASIN_RE.test(own)) return own;
    for (const a of el.querySelectorAll('a[href]')) {
      const m = DP_IN_HREF.exec(a.getAttribute('href') || '');
      if (m && ASIN_RE.test(m[1].toUpperCase())) return m[1].toUpperCase();
    }
    return null;
  };
  const scanCarousels = () => {
    const params = new URLSearchParams(location.search);
    const inBooksDept = /^stripbooks/i.test(params.get('i') || '');
    const cards = document.querySelectorAll('.a-carousel-card:not([data-lemon]), li.a-carousel-card:not([data-lemon])');
    const jobs = [];
    for (const card of cards) {
      if (card.closest('[data-component-type="s-search-result"]') || card.closest('[data-lemon-badge]')) continue;
      const titleEl = card.querySelector('h2, h3, [class*="title"], .a-truncate-full, [data-cy="title-recipe"]');
      const title = (titleEl?.textContent || card.querySelector('img')?.getAttribute('alt') || '').trim();
      const asin = carouselAsin(card);
      if (!title || !asin) continue; // карточка ещё не дорисована — вернёмся позже
      card.setAttribute('data-lemon', '1');
      if (!isColoringText(title)) continue;
      // Не книга («coloring markers»): нужен раздел Books, формат книги в карточке или ASIN-ISBN бумажной книги
      const bookish = /\bbooks?\b|\bpages\b|libro|livre|buch|boek|ksi[aą]ż|塗り絵|ぬりえ|раскраск/i.test(title);
      if (!(inBooksDept || bookish || FORMAT_RE.test(card.textContent || '') || /^\d{9}[\dX]$/.test(asin))) continue;
      const badge = createBadge();
      const host = titleEl?.closest('a') || titleEl;
      if (host && host.parentElement && host.parentElement !== card) host.insertAdjacentElement('afterend', badge.host);
      else card.append(badge.host);
      jobs.push({
        asin,
        badge,
        el: card,
        meta: { title: cleanText(title, 300) || null, author: null, coverUrl: normCover(card.querySelector('img')?.getAttribute('src')) },
      });
    }
    applyStats(jobs);
    reportSeen(jobs.map((j) => ({ asin: j.asin, ...j.meta })));
  };

  // Страница автора (Home и All Books). Плитки книг — веб-компоненты Amazon, у каждой плитки ASIN лежит в
  // data-csa-c-item-id (на Home «B0…», в All Books «amzn1.asin.B0…»). Ссылки внутри плитки брать нельзя:
  // они в теневом DOM, а ссылка «Part of: серия» ведёт на другую книгу. Плашка только у раскрасок (по названию).
  const AUTHOR_TILES = 'bds-unified-book-faceout[data-csa-c-item-id], li[data-testid="product-grid-item"][data-csa-c-item-id]';
  const tileAsin = (el) => {
    const v = (el.getAttribute('data-csa-c-item-id') || '').replace(/^amzn1\.asin\./i, '').toUpperCase();
    return ASIN_RE.test(v) ? v : null;
  };
  // Полное название плитки (в All Books видимое название обрезано «…», поэтому берём из атрибутов ссылки/обложки)
  const tileTitle = (tile) => {
    if (tile.localName === 'bds-unified-book-faceout') {
      const r = tile.shadowRoot;
      return (
        r?.querySelector('.cover-image-link')?.getAttribute('aria-label') ||
        r?.querySelector('bds-book-cover-image')?.getAttribute('coverimagealttext') ||
        r?.querySelector('img')?.getAttribute('alt') ||
        ''
      ).trim();
    }
    const link = tile.querySelector('a[title], a[aria-label]');
    return (
      link?.getAttribute('title') ||
      link?.getAttribute('aria-label') ||
      tile.querySelector('[data-testid="product-grid-title"]')?.textContent ||
      tile.querySelector('img[alt]')?.getAttribute('alt') ||
      ''
    ).trim();
  };
  const hasBadge = (tile) =>
    tile.localName === 'bds-unified-book-faceout'
      ? tile.nextElementSibling?.hasAttribute('data-lemon-badge')
      : !!tile.querySelector('[data-lemon-badge]');
  const scanAuthor = () => {
    const jobs = [];
    for (const tile of document.querySelectorAll(AUTHOR_TILES)) {
      if (hasBadge(tile) || tile.hasAttribute('data-lemon-skip')) continue;
      const asin = tileAsin(tile);
      if (!asin) continue;
      const title = tileTitle(tile);
      if (!title) continue; // плитка ещё не дорисована — вернёмся позже
      if (!isColoringText(title)) {
        tile.setAttribute('data-lemon-skip', '1'); // не раскраска — плашку не показываем
        continue;
      }
      const badge = createBadge();
      if (tile.localName === 'bds-unified-book-faceout') {
        // Home: плашка сразу под плиткой (сама плитка — закрытый компонент, внутрь её тени не лезем)
        tile.insertAdjacentElement('afterend', badge.host);
      } else {
        // All Books: под названием; если вёрстка изменилась — в конец блока с информацией, иначе в конец плитки
        const title = tile.querySelector('[data-testid="product-grid-title"]')?.parentElement;
        const info = tile.querySelector('[data-testid="grid-item-info"]');
        if (title) title.insertAdjacentElement('afterend', badge.host);
        else (info || tile).append(badge.host);
      }
      const img = tile.shadowRoot?.querySelector('img') || tile.querySelector('img');
      jobs.push({
        asin,
        badge,
        el: tile,
        meta: { title: cleanText(title, 300) || null, author: null, coverUrl: normCover(img?.getAttribute('src')) },
      });
    }
    applyStats(jobs);
    reportSeen(jobs.map((j) => ({ asin: j.asin, ...j.meta })));
  };

  // ------------------------------------------------------------- главный цикл
  const product = { asin: null, host: null, widget: null, since: 0, formatsDone: false };

  // Переключатель форматов может дорисоваться позже блока, поэтому проверяем его в течение 30 секунд.
  const watchFormats = (asin) => {
    if (product.formatsDone || Date.now() - product.since > 30000) return;
    const formats = formatAsins(asin);
    if (formats.length < 2) return;
    product.formatsDone = true;
    send({ type: 'reportFormats', marketplace, asins: formats }).then((resp) => {
      // reported: сервер принял новую связь — обновляем сводку (оценки форматов объединились)
      if (resp.ok && resp.reported && product.asin === asin) product.widget?.refresh();
    });
  };

  const mountProduct = (asin) => {
    const anchor =
      document.querySelector('#bylineInfo_feature_div') ||
      document.querySelector('#title_feature_div') ||
      document.querySelector('#titleSection');
    const fallback = document.querySelector('#centerCol');
    if (!anchor && !fallback) return;
    const widget = createProductWidget(asin);
    if (anchor) anchor.insertAdjacentElement('afterend', widget.host);
    else fallback.prepend(widget.host);
    product.host = widget.host;
    product.widget = widget;
    product.since = Date.now();
    product.formatsDone = false;
    widget.load();
  };

  const tick = () => {
    if (!alive()) {
      // расширение обновили/перезагрузили — этот скрипт осиротел
      clearInterval(interval);
      observer.disconnect();
      return;
    }
    const kind = pageKind();
    if (kind === 'product') {
      const asin = productAsin();
      if (product.asin !== asin) {
        product.host?.remove(); // Amazon переключил формат/вариант без перезагрузки страницы
        product.asin = asin;
        product.host = null;
        product.widget = null;
      }
      if (product.host?.isConnected) {
        watchFormats(asin);
        return;
      }
      if (!isBookProduct() || !isColoringProduct()) return;
      mountProduct(asin);
    } else {
      if (product.host) {
        product.host.remove();
        product.host = null;
        product.asin = null;
      }
      if (kind === 'search') {
        scanSearch();
        scanCarousels();
      }
      if (kind === 'author') scanAuthor();
    }
  };

  let timer = null;
  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(tick, 300);
  };
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  const interval = setInterval(tick, 2000);
  tick();
})();
