// Lemon Score — окошко при нажатии на иконку расширения.
// Здесь: переключатель подсветки неоценённых книг и выгрузка списка «мои книги» в CSV.
// Тексты по умолчанию английские (в popup.html); для русского браузера подменяем.
const ru = (navigator.language || 'en').toLowerCase().startsWith('ru');
const T = ru
  ? {
      desc: 'Оценки пользователей: насколько вероятно, что раскраска на Amazon сделана ИИ. Откройте страницу раскраски на Amazon, чтобы посмотреть или добавить оценку.',
      highlightLbl: 'Подсвечивать книги без моей оценки',
      highlightHint: 'Оранжевая рамка в поиске Amazon, на страницах авторов и книг.',
      libTitle: 'Мои книги',
      lblSeen: 'просмотрено',
      lblRated: 'оценено',
      lblTodo: 'осталось',
      scopeAll: 'Все книги',
      scopeRated: 'Оценённые мной',
      scopeUnrated: 'Не оценённые мной',
      exportBtn: 'Скачать CSV',
      loading: 'Загружаю список…',
      errLoad: 'Не удалось загрузить список. Если вы только что обновили расширение, обновите и схему в Supabase.',
      errNotConfigured: 'Расширение не настроено (см. config.js).',
      empty: 'В этой выгрузке пока нет книг.',
      done: (n) => `Готово: ${n} в файле.`,
      open: 'Открыть сайт Lemon Score',
      cols: ['ASIN', 'Название', 'Автор', 'Ссылка', 'Статус', 'Моя оценка (0-5)', 'Дата оценки', 'Впервые увидена', 'Последний раз увидена', 'Оценок у всех', 'Среднее у всех (0-5)', 'Обложка'],
      rated: 'оценена',
      unrated: 'не оценена',
    }
  : {
      desc: 'User ratings of how likely coloring books on Amazon are AI-made. Open a coloring book page on Amazon to see or add a rating.',
      highlightLbl: "Highlight books I haven't rated",
      highlightHint: 'Orange frame on Amazon search results, author pages and book pages.',
      libTitle: 'My books',
      lblSeen: 'seen',
      lblRated: 'rated',
      lblTodo: 'to rate',
      scopeAll: 'All books',
      scopeRated: 'Rated by me',
      scopeUnrated: 'Not rated by me',
      exportBtn: 'Download CSV',
      loading: 'Loading the list…',
      errLoad: 'Could not load the list. If you just updated the extension, update the Supabase schema too.',
      errNotConfigured: 'The extension is not configured (see config.js).',
      empty: 'There are no books in this export yet.',
      done: (n) => `Done: ${n} in the file.`,
      open: 'Open the Lemon Score website',
      cols: ['ASIN', 'Title', 'Author', 'URL', 'Status', 'My rating (0-5)', 'Rated on', 'First seen', 'Last seen', 'Ratings by everyone', 'Average by everyone (0-5)', 'Cover'],
      rated: 'rated',
      unrated: 'not rated',
    };

const $ = (id) => document.getElementById(id);
const setText = (id, text) => {
  $(id).textContent = text;
};

document.documentElement.lang = ru ? 'ru' : 'en';
setText('desc', T.desc);
setText('highlightLbl', T.highlightLbl);
setText('highlightHint', T.highlightHint);
setText('libTitle', T.libTitle);
setText('lblSeen', T.lblSeen);
setText('lblRated', T.lblRated);
setText('lblTodo', T.lblTodo);
setText('export', T.exportBtn);
setText('open', T.open);
$('scope').options[0].textContent = T.scopeAll;
$('scope').options[1].textContent = T.scopeRated;
$('scope').options[2].textContent = T.scopeUnrated;

// ---------------------------------------------------------------- подсветка
const SETTINGS_KEY = 'settings';
const box = $('highlight');
chrome.storage.local.get(SETTINGS_KEY).then(({ settings }) => {
  box.checked = settings?.highlightUnrated !== false; // по умолчанию включена
});
box.addEventListener('change', async () => {
  const { settings } = await chrome.storage.local.get(SETTINGS_KEY);
  await chrome.storage.local.set({ [SETTINGS_KEY]: { ...(settings || {}), highlightUnrated: box.checked } });
});

// ---------------------------------------------------------------- моя библиотека и выгрузка
let library = null; // строки get_my_library
const msg = (text, kind = '') => {
  const el = $('msg');
  el.textContent = text || '';
  el.className = 'msg' + (kind ? ' ' + kind : '');
};
const isRated = (r) => r.my_ai_score != null;

const loadLibrary = async () => {
  msg(T.loading);
  let resp;
  try {
    resp = await chrome.runtime.sendMessage({ type: 'getMyLibrary' });
  } catch {
    resp = null;
  }
  if (!resp?.ok) {
    msg(resp?.error === 'not_configured' ? T.errNotConfigured : T.errLoad, 'err');
    return;
  }
  library = resp.library || [];
  const rated = library.filter(isRated).length;
  setText('nSeen', String(library.length));
  setText('nRated', String(rated));
  setText('nTodo', String(library.length - rated));
  $('stats').hidden = false;
  $('export').disabled = false;
  msg('');
};

const SEP = ru ? ';' : ','; // русский Excel ждёт «;», Google Таблицы и остальные понимают оба
const cell = (v) => {
  let s = v == null ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // чтобы Excel не принял текст из Amazon за формулу
  return /[";,\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
const day = (iso) => (iso ? String(iso).slice(0, 10) : '');

const buildCsv = (rows) => {
  const lines = [T.cols.map(cell).join(SEP)];
  for (const r of rows) {
    lines.push(
      [
        r.asin,
        r.title,
        r.author,
        `https://www.amazon.${r.marketplace || 'com'}/dp/${r.asin}`,
        isRated(r) ? T.rated : T.unrated,
        isRated(r) ? r.my_ai_score : '',
        day(r.rated_at),
        day(r.first_seen_at),
        day(r.last_seen_at),
        r.ratings_count || 0,
        r.avg_ai ?? '',
        r.cover_url,
      ]
        .map(cell)
        .join(SEP)
    );
  }
  return '﻿' + lines.join('\r\n') + '\r\n'; // BOM, чтобы Excel правильно прочитал кириллицу
};

$('export').addEventListener('click', async () => {
  if (!library) await loadLibrary();
  if (!library) return;
  const scope = $('scope').value;
  const rows = library.filter((r) => (scope === 'rated' ? isRated(r) : scope === 'unrated' ? !isRated(r) : true));
  if (!rows.length) {
    msg(T.empty, 'err');
    return;
  }
  const blob = new Blob([buildCsv(rows)], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `lemon-score-${scope}-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  msg(T.done(rows.length), 'ok');
});

loadLibrary();
