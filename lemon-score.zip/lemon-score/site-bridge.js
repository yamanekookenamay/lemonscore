// Lemon Score — мостик между расширением и сайтом Lemon Score.
// Запускается только на страницах сайта (см. content_scripts в manifest.json).
// Сайт не может прочитать данные расширения сам, поэтому спрашивает через window.postMessage,
// а этот скрипт отвечает списком книг, которые оценило и которые просто видело это устройство.
// Отдаётся только «маркетплейс + ASIN + оценка»; ID устройства странице не передаётся.
(() => {
  'use strict';
  if (window.__lemonScoreBridge) return;
  window.__lemonScoreBridge = true;

  const VERSION = chrome.runtime.getManifest().version;
  const reply = (data) => window.postMessage({ source: 'lemon-score-extension', version: VERSION, ...data }, location.origin);

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const msg = event.data;
    if (!msg || msg.source !== 'lemon-score-site') return;

    if (msg.type === 'ping') {
      reply({ type: 'pong', id: msg.id });
      return;
    }
    if (msg.type === 'getMyRatings') {
      let resp;
      try {
        resp = (await chrome.runtime.sendMessage({ type: 'getMyRatings' })) || { ok: false, error: 'network' };
      } catch {
        resp = { ok: false, error: 'context' }; // расширение обновили — нужна перезагрузка страницы
      }
      reply({ type: 'myRatings', id: msg.id, ok: !!resp.ok, error: resp.error || null, ratings: resp.ratings || [] });
    }
    if (msg.type === 'getMyLibrary') {
      // Все книги устройства: и оценённые, и увиденные. Отдаём только «магазин + ASIN + оценка»
      // (оценка null — книгу ещё не оценили); названия, обложки и ID устройства странице не передаются.
      let resp;
      try {
        resp = (await chrome.runtime.sendMessage({ type: 'getMyLibrary' })) || { ok: false, error: 'network' };
      } catch {
        resp = { ok: false, error: 'context' };
      }
      const items = (resp.library || []).map((r) => ({ marketplace: r.marketplace, asin: r.asin, ai_score: r.my_ai_score ?? null }));
      reply({ type: 'myLibrary', id: msg.id, ok: !!resp.ok, error: resp.error || null, items });
    }
  });

  // Сообщаем сайту, что расширение установлено (на случай, если сайт загрузился раньше мостика).
  document.documentElement.setAttribute('data-lemon-score-extension', VERSION);
  reply({ type: 'ready' });
})();
