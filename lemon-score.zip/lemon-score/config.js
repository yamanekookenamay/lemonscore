// Заполните после создания проекта в Supabase (Project Settings → API).
export const CONFIG = {
  SUPABASE_URL: 'https://uhxmxanuayxlzhmednbx.supabase.co',
  // Публичный ключ: "anon" (legacy, начинается с eyJ...) или "publishable" (sb_publishable_...).
  // НИКОГДА не вставляйте сюда secret / service_role ключ.
  SUPABASE_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVoeG14YW51YXl4bHpobWVkbmJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM0MTI1OTksImV4cCI6MjEwODk4ODU5OX0.3tSnb9tXnJqwfcadyYVO956BaIMj9140T8WKRTdIruc',
};
