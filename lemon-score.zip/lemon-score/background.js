// Lemon Score — service worker.
// Все запросы к серверу идут отсюда (а не из content script), чтобы страницы Amazon
// не видели ключ и не упирались в CORS. Здесь же живёт ID устройства.
import { CONFIG } from './config.js';

const MARKETPLACE_RE = /^[a-z]{2,3}(\.[a-z]{2,3})?$/;
const ASIN_RE = /^[A-Z0-9]{10}$/;
const ALLOWED_FLAGS = new Set([
  'bad_anatomy',
  'gibberish_text',
  'repetitive',
  'messy_lines',
  'inconsistent',
  'cover_mismatch',
]);
const MAX_ASINS_PER_REQUEST = 50; // сервер принимает до 60
const CACHE_TTL_MS = 2 * 60 * 1000;
const REQUEST_TIMEOUT_MS = 10000;

// Кэш сводок в памяти (best effort: service worker может «засыпать»).
const cache = new Map(); // `${marketplace}:${asin}` -> { t, row | null }

const isConfigured = () =>
  typeof CONFIG.SUPABASE_URL === 'string' &&
  typeof CONFIG.SUPABASE_KEY === 'string' &&
  !CONFIG.SUPABASE_URL.includes('YOUR-') &&
  !CONFIG.SUPABASE_KEY.includes('YOUR-');

// ---------- ID устройства ----------
// Случайный UUID, создаётся при первом запуске. Никак не связан с личностью.
let devicePromise = null;
const getDeviceId = () =>
  (devicePromise ??= (async () => {
    const { deviceId } = await chrome.storage.local.get('deviceId');
    if (deviceId) return deviceId;
    const id = crypto.randomUUID();
    await chrome.storage.local.set({ deviceId: id });
    return id;
  })());

// ---------- Supabase RPC ----------
const headers = () => {
  const h = { 'Content-Type': 'application/json', apikey: CONFIG.SUPABASE_KEY };
  // Legacy anon-ключ — это JWT, ему нужен и заголовок Authorization.
  // Новые publishable-ключи (sb_publishable_...) передаются только в apikey.
  if (CONFIG.SUPABASE_KEY.startsWith('eyJ')) h.Authorization = `Bearer ${CONFIG.SUPABASE_KEY}`;
  return h;
};

const rpc = async (fn, body) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
  try {
    const base = CONFIG.SUPABASE_URL.replace(/\/+$/, '');
    const res = await fetch(`${base}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`http_${res.status}: ${text.slice(0, 300)}`);
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
};

// ---------- Обработчики ----------
const cleanAsins = (list) => [
  ...new Set(
    (Array.isArray(list) ? list : [])
      .map((a) => String(a).toUpperCase())
      .filter((a) => ASIN_RE.test(a))
  ),
].slice(0, 200);

const getStats = async (msg) => {
  const marketplace = String(msg.marketplace || '');
  if (!MARKETPLACE_RE.test(marketplace)) throw new Error('bad_request');
  const asins = cleanAsins(msg.asins);
  const deviceId = await getDeviceId();

  const now = Date.now();
  const stats = {};
  const missing = [];
  for (const asin of asins) {
    const hit = cache.get(`${marketplace}:${asin}`);
    if (hit && now - hit.t < CACHE_TTL_MS) {
      if (hit.row) stats[asin] = hit.row;
    } else {
      missing.push(asin);
    }
  }

  for (let i = 0; i < missing.length; i += MAX_ASINS_PER_REQUEST) {
    const chunk = missing.slice(i, i + MAX_ASINS_PER_REQUEST);
    const rows = await rpc('get_book_stats', {
      p_marketplace: marketplace,
      p_asins: chunk,
      p_device_id: deviceId,
    });
    const byAsin = new Map((rows || []).map((r) => [r.asin, r]));
    for (const asin of chunk) {
      const row = byAsin.get(asin) || null;
      cache.set(`${marketplace}:${asin}`, { t: now, row });
      if (row) stats[asin] = row;
    }
  }
  return { ok: true, stats };
};

const submitRating = async (msg) => {
  const marketplace = String(msg.marketplace || '');
  const asin = String(msg.asin || '').toUpperCase();
  const ai = msg.aiScore;
  const quality = msg.qualityScore ?? null;
  const flags = Array.isArray(msg.flags) ? msg.flags : [];

  if (!MARKETPLACE_RE.test(marketplace) || !ASIN_RE.test(asin)) throw new Error('bad_request');
  if (!Number.isInteger(ai) || ai < 0 || ai > 5) throw new Error('bad_request');
  if (quality !== null && (!Number.isInteger(quality) || quality < 1 || quality > 5)) throw new Error('bad_request');
  if (flags.length > 6 || !flags.every((f) => ALLOWED_FLAGS.has(f))) throw new Error('bad_request');

  const deviceId = await getDeviceId();
  const meta = cleanMeta(msg);
  const result = await rpc('submit_rating', {
    p_marketplace: marketplace,
    p_asin: asin,
    p_device_id: deviceId,
    p_ai_score: ai,
    p_quality_score: quality,
    p_flags: flags,
    p_title: meta.title,
    p_author: meta.author,
    p_cover_url: meta.cover,
  });
  invalidateMine(); // списки «мои оценки» / «моя библиотека» устарели

  // Форматы одной книги делят оценки: после оценки устарели сводки и у соседних форматов, не только у этого.
  cache.clear();
  const key = `${marketplace}:${asin}`;
  if (result?.stats) cache.set(key, { t: Date.now(), row: result.stats });
  return { ok: true, result };
};

// ---------- Данные книги для сайта ----------
const COVER_RE =
  /^https:\/\/(m\.media-amazon\.com|images-na\.ssl-images-amazon\.com|images-eu\.ssl-images-amazon\.com|images-fe\.ssl-images-amazon\.com)\/images\/[IP]\/[A-Za-z0-9._%+,-]+$/;
const cleanStr = (v, max) => {
  const s = typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '';
  return s || null;
};
const cleanMeta = (msg) => {
  const cover = typeof msg.coverUrl === 'string' && COVER_RE.test(msg.coverUrl) ? msg.coverUrl : null;
  return { title: cleanStr(msg.title, 300), author: cleanStr(msg.author, 120), cover };
};

// Досылка данных книги не чаще раза в неделю на книгу (чтобы не дёргать сервер на каждом просмотре).
const META_RESEND_MS = 7 * 24 * 60 * 60 * 1000;
const upsertMeta = async (msg) => {
  const marketplace = String(msg.marketplace || '');
  const asin = String(msg.asin || '').toUpperCase();
  if (!MARKETPLACE_RE.test(marketplace) || !ASIN_RE.test(asin)) throw new Error('bad_request');
  const meta = cleanMeta(msg);
  if (!meta.title && !meta.author && !meta.cover) return { ok: true, skipped: true };

  const key = `${marketplace}:${asin}`;
  const { metaSent = {} } = await chrome.storage.local.get('metaSent');
  const now = Date.now();
  if (metaSent[key] && now - metaSent[key] < META_RESEND_MS) return { ok: true, skipped: true };

  const saved = await rpc('upsert_book_meta', {
    p_marketplace: marketplace,
    p_asin: asin,
    p_title: meta.title,
    p_author: meta.author,
    p_cover_url: meta.cover,
  });
  // чистим старые отметки, чтобы хранилище не росло бесконечно
  for (const [k, t] of Object.entries(metaSent)) if (now - t > META_RESEND_MS) delete metaSent[k];
  metaSent[key] = now;
  await chrome.storage.local.set({ metaSent });
  cache.delete(key);
  return { ok: true, saved: !!saved };
};

// ---------- Форматы одной книги ----------
// Расширение присылает ASIN из переключателя форматов (Paperback / Spiral-bound / Kindle ...),
// сервер считает их одной книгой. Один и тот же набор отправляется не чаще раза в неделю.
const FORMATS_RESEND_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_FORMATS = 8; // держать в синхроне с c_max_group в schema.sql
const reportFormats = async (msg) => {
  const marketplace = String(msg.marketplace || '');
  if (!MARKETPLACE_RE.test(marketplace)) throw new Error('bad_request');
  const asins = cleanAsins(msg.asins).sort();
  if (asins.length < 2 || asins.length > MAX_FORMATS) return { ok: true, skipped: true };

  const key = `${marketplace}:${asins.join(',')}`;
  const { formatsSent = {} } = await chrome.storage.local.get('formatsSent');
  const now = Date.now();
  if (formatsSent[key] && now - formatsSent[key] < FORMATS_RESEND_MS) return { ok: true, skipped: true };

  const deviceId = await getDeviceId();
  const result = await rpc('report_formats', { p_marketplace: marketplace, p_asins: asins, p_device_id: deviceId });
  if (result?.status !== 'ok') return { ok: true, skipped: true, status: result?.status || 'error' };

  for (const [k, t] of Object.entries(formatsSent)) if (now - t > FORMATS_RESEND_MS) delete formatsSent[k];
  formatsSent[key] = now;
  await chrome.storage.local.set({ formatsSent });
  cache.clear(); // группы изменились — сводки по этим книгам устарели
  invalidateMine();
  return { ok: true, reported: true };
};

// ---------- Увиденные книги ----------
// Расширение сообщает серверу, какие раскраски пользователь видел (карточки в поиске, плитки на страницах
// авторов, страницы книг), даже если не оценивал их. Из этого строится очередь «что ещё оценить»,
// которую видно на сайте и в выгрузке.
const SEEN_RESEND_MS = 24 * 60 * 60 * 1000; // одну и ту же книгу пересылаем не чаще раза в сутки...
const SEEN_FORGET_MS = 30 * 24 * 60 * 60 * 1000; // ...а отметки старше 30 дней забываем
const SEEN_CHUNK = 60; // сервер принимает до 60 книг за раз
const SEEN_BACKOFF_MS = 10 * 60 * 1000; // после ошибки сервера (функции нет, лимит) паузу выдерживаем
let seenBackoffUntil = 0;
let seenSent = null; // asin -> [время отправки, маска данных]; зеркало chrome.storage.local.seenSent

const metaMask = (m) => (m.title ? 1 : 0) | (m.author ? 2 : 0) | (m.cover ? 4 : 0);

const recordSeen = async (msg) => {
  if (Date.now() < seenBackoffUntil) return { ok: true, skipped: true };
  seenSent ??= (await chrome.storage.local.get('seenSent')).seenSent || {};
  const now = Date.now();

  const items = [];
  const masks = new Map();
  for (const raw of (Array.isArray(msg.items) ? msg.items : []).slice(0, 300)) {
    const asin = String(raw?.asin || '').toUpperCase();
    if (!ASIN_RE.test(asin) || masks.has(asin)) continue;
    const meta = cleanMeta(raw);
    const mask = metaMask(meta);
    const prev = seenSent[asin];
    // Шлём, если книги ещё не было, прошли сутки или появились данные, которых раньше не было.
    if (prev && now - prev[0] < SEEN_RESEND_MS && (mask & ~prev[1]) === 0) continue;
    masks.set(asin, mask);
    items.push({ asin, title: meta.title, author: meta.author, cover_url: meta.cover });
  }
  if (!items.length) return { ok: true, skipped: true };

  const deviceId = await getDeviceId();
  let saved = 0;
  try {
    for (let i = 0; i < items.length; i += SEEN_CHUNK) {
      const chunk = items.slice(i, i + SEEN_CHUNK);
      const result = await rpc('record_sightings', { p_device_id: deviceId, p_items: chunk });
      if (result?.status !== 'ok') {
        seenBackoffUntil = now + SEEN_BACKOFF_MS; // rate_limited / capped / error
        break;
      }
      for (const it of chunk) seenSent[it.asin] = [now, masks.get(it.asin)];
      saved += chunk.length;
    }
  } catch (e) {
    // функции на сервере ещё нет (схему не обновили) или она недоступна — не долбим сервер каждую секунду
    if (/^http_4/.test(String(e?.message))) seenBackoffUntil = now + SEEN_BACKOFF_MS;
    throw e;
  } finally {
    for (const [k, v] of Object.entries(seenSent)) if (now - v[0] > SEEN_FORGET_MS) delete seenSent[k];
    await chrome.storage.local.set({ seenSent });
    if (saved) invalidateMine();
  }
  return { ok: true, saved };
};

// ---------- «Моя библиотека»: оценённые и увиденные книги ----------
// Сайт получает из неё только «магазин + ASIN + оценка», выгрузка в окошке расширения — всё вместе с названиями.
// ID устройства наружу не уходит.
const MINE_TTL_MS = 30 * 1000;
const LIBRARY_PAGE = 1000; // PostgREST отдаёт не больше 1000 строк за запрос
let libraryCache = null; // { t, list }
let myRatingsCache = null; // { t, list }
const invalidateMine = () => {
  libraryCache = null;
  myRatingsCache = null;
};

const getMyLibrary = async () => {
  if (libraryCache && Date.now() - libraryCache.t < MINE_TTL_MS) return { ok: true, library: libraryCache.list };
  const deviceId = await getDeviceId();
  const list = [];
  for (let offset = 0; offset < 200000; offset += LIBRARY_PAGE) {
    const rows = await rpc('get_my_library', { p_device_id: deviceId, p_limit: LIBRARY_PAGE, p_offset: offset });
    if (!Array.isArray(rows)) break;
    list.push(...rows);
    if (rows.length < LIBRARY_PAGE) break;
  }
  libraryCache = { t: Date.now(), list };
  return { ok: true, library: list };
};

const getMyRatings = async () => {
  if (myRatingsCache && Date.now() - myRatingsCache.t < MINE_TTL_MS) return { ok: true, ratings: myRatingsCache.list };
  let list;
  try {
    const { library } = await getMyLibrary();
    list = library
      .filter((r) => r.my_ai_score != null)
      .map((r) => ({ marketplace: r.marketplace, asin: r.asin, ai_score: r.my_ai_score, updated_at: r.rated_at }));
  } catch (e) {
    if (!/^http_404/.test(String(e?.message))) throw e;
    // Схему на сервере ещё не обновили (нет get_my_library) — берём старую функцию.
    const deviceId = await getDeviceId();
    const rows = await rpc('get_my_ratings', { p_device_id: deviceId });
    list = (rows || []).map((r) => ({ marketplace: r.marketplace, asin: r.asin, ai_score: r.ai_score, updated_at: r.updated_at }));
  }
  myRatingsCache = { t: Date.now(), list };
  return { ok: true, ratings: list };
};

const toErrorCode = (e) =>
  e?.name === 'AbortError' || e instanceof TypeError ? 'network' : String(e?.message || 'error');

const handle = async (msg) => {
  if (!isConfigured()) return { ok: false, error: 'not_configured' };
  try {
    if (msg?.type === 'getStats') return await getStats(msg);
    if (msg?.type === 'submitRating') return await submitRating(msg);
    if (msg?.type === 'upsertMeta') return await upsertMeta(msg);
    if (msg?.type === 'reportFormats') return await reportFormats(msg);
    if (msg?.type === 'getMyRatings') return await getMyRatings();
    if (msg?.type === 'getMyLibrary') return await getMyLibrary();
    if (msg?.type === 'recordSeen') return await recordSeen(msg);
    return { ok: false, error: 'bad_request' };
  } catch (e) {
    return { ok: false, error: toErrorCode(e) };
  }
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handle(msg).then(sendResponse);
  return true; // ответ придёт асинхронно
});
